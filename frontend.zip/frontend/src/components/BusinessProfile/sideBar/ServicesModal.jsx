import { useState } from "react";
import styles from "./ServicesModal.module.css";

export default function ServicesModal({ services, onSave, onClose }) {
  const [list, setList] = useState(services || []);
  const [newName, setNewName] = useState("");
  const [newDuration, setNewDuration] = useState(30);

  // הוספת שירות חדש
  const addService = () => {
    if (!newName.trim()) return;
    setList([...list, { name: newName.trim(), duration: Number(newDuration) }]);
    setNewName("");
    setNewDuration(30);
  };

  // מחיקת שירות
  const removeService = (idx) => {
    setList(list.filter((_, i) => i !== idx));
  };

  // עדכון שם או משך של שירות
  const updateService = (idx, key, value) => {
    const updated = list.map((s, i) =>
      i === idx ? { ...s, [key]: value } : s
    );
    setList(updated);
  };

  return (
    <div className={styles.modalBackdrop}>
      <div className={styles.modal}>
        <h3>ניהול שירותים</h3>
        <ul>
          {list.map((service, i) => (
            <li key={i}>
              <input
                value={service.name}
                onChange={(e) => updateService(i, "name", e.target.value)}
                placeholder="שם השירות"
              />
              <input
                type="number"
                min="5"
                max="180"
                value={service.duration}
                onChange={(e) => updateService(i, "duration", e.target.value)}
                style={{ width: "60px" }}
              />{" "}
              דקות
              <button
                className={styles.removeBtn}
                onClick={() => removeService(i)}
                title="מחק"
                tabIndex={-1}
              >
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                  <path
                    d="M5 5 L15 15 M15 5 L5 15"
                    stroke="#ff4160"
                    strokeWidth="2"
                    strokeLinecap="round"
                  />
                </svg>
              </button>
            </li>
          ))}
        </ul>

        <div className={styles.addServiceRow}>
          <input
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="שם שירות חדש"
          />
          <input
            type="number"
            min="5"
            max="180"
            value={newDuration}
            onChange={(e) => setNewDuration(e.target.value)}
            style={{ width: "70px" }}
          />{" "}
          דקות
          <button onClick={addService}>הוסף שירות</button>
        </div>

        <div className={styles.bottomBtns}>
          <button onClick={() => onSave(list)}>שמור</button>
          <button onClick={onClose}>ביטול</button>
        </div>
      </div>
    </div>
  );
}
