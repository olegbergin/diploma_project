import { useState } from "react";
import styles from "./BookingModal.module.css";

/**
 * @param dateIso      "YYYY-MM-DD" (היום הנבחר)
 * @param takenSlots   ["HH:MM", ...]  – שעות שכבר תפוסות
 * @param onSubmit     function(timeStr) – יישלח בשלב הבא ל-API
 * @param onClose      () => void
 */
export default function BookingModal({
  dateIso,
  takenSlots,
  onSubmit,
  onClose,
}) {
  /* כל חצי-שעה בין 08:00-20:00 */
  const all = Array.from(
    { length: 25 },
    (_, i) =>
      String(8 + Math.floor(i / 2)).padStart(2, "0") +
      ":" +
      (i % 2 === 0 ? "00" : "30")
  );

  const [picked, setPicked] = useState("");

  const handleSave = () => {
    if (!picked) return;
    onSubmit(picked); // בשלב הבא: POST ל-/api/requests
    onClose();
  };

  return (
    <div className={styles.backdrop}>
      <div className={styles.card}>
        <h3>{new Date(dateIso).toLocaleDateString("he-IL")}</h3>

        <div className={styles.grid}>
          {all.map((t) => {
            const busy = takenSlots.includes(t);
            return (
              <button
                key={t}
                disabled={busy}
                className={`${styles.slot} ${
                  picked === t ? styles.selected : ""
                } ${busy ? styles.busy : ""}`}
                onClick={() => setPicked(t)}
              >
                {t}
              </button>
            );
          })}
        </div>

        <div className={styles.actions}>
          <button onClick={onClose}>ביטול</button>
          <button disabled={!picked} onClick={handleSave}>
            בקשת תור
          </button>
        </div>
      </div>
    </div>
  );
}
